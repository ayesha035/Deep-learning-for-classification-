import os
import pandas as pd
from keras.models import Model, Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization, ReLU, GlobalAveragePooling2D
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import ModelCheckpoint, CSVLogger
from keras.optimizers import Adam
import tensorflow as tf

# ? Define directories
train_folder = "/home5/ayesha.cse/mycode/data/train_data"
epoch_results_folder = "/home5/ayesha.cse/mycode/data/epoch_results/"
logs_folder = "/home5/ayesha.cse/mycode/data/logs/"

# ? Ensure epoch results and logs folders exist
os.makedirs(epoch_results_folder, exist_ok=True)
os.makedirs(logs_folder, exist_ok=True)

# ? Hyperparameters
batch_size = 16
epochs = 3  # Keeping same as before
num_classes = 3  # Number of classes in dataset
input_shape = (512, 512, 3)  # Image size same as before

# ? Create ImageDataGenerator with validation split
datagen = ImageDataGenerator(rescale=1.0/255.0, validation_split=0.3)  # ?? Validation split 30%

# ? Training Data
train_generator = datagen.flow_from_directory(
    train_folder,
    target_size=(512, 512),
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=True,
    subset='training'
)

# ? Validation Data
val_generator = datagen.flow_from_directory(
    train_folder,
    target_size=(512, 512),
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=False,
    subset='validation'
)

# ? Print dataset sizes before training
print(f"? Total Training Samples: {train_generator.samples}")
print(f"? Total Validation Samples: {val_generator.samples}")

# ? Define AlexNet model
model = Sequential([
    Conv2D(96, kernel_size=(11, 11), strides=4, activation='relu', input_shape=input_shape),
    MaxPooling2D(pool_size=(3, 3), strides=2),
    BatchNormalization(),

    Conv2D(256, kernel_size=(5, 5), activation='relu', padding='same'),
    MaxPooling2D(pool_size=(3, 3), strides=2),
    BatchNormalization(),

    Conv2D(384, kernel_size=(3, 3), activation='relu', padding='same'),
    Conv2D(384, kernel_size=(3, 3), activation='relu', padding='same'),
    Conv2D(256, kernel_size=(3, 3), activation='relu', padding='same'),
    MaxPooling2D(pool_size=(3, 3), strides=2),
    BatchNormalization(),

    Flatten(),
    Dense(4096, activation='relu'),
    Dropout(0.5),
    Dense(4096, activation='relu'),
    Dropout(0.5),
    Dense(num_classes, activation='softmax')
])

# ? Compile the model
model.compile(optimizer=Adam(learning_rate=0.00001), 
              loss=tf.keras.losses.CategoricalCrossentropy(from_logits=False),
              metrics=['accuracy'])

# ? Save model checkpoints after each epoch
checkpoint_callback = ModelCheckpoint(
    filepath=os.path.join(epoch_results_folder, 'epoch_{epoch:02d}.h5'),
    monitor='val_accuracy',
    save_best_only=True,
    verbose=1
)

# ? Save training logs to CSV for each epoch
csv_logger = CSVLogger(os.path.join(logs_folder, 'training_log.csv'), append=True)

# ? Train the model and print progress
history = model.fit(
    train_generator,
    validation_data=val_generator,  
    epochs=epochs,
    callbacks=[checkpoint_callback, csv_logger]
)

# ? Print final training and validation accuracy
final_train_acc = history.history['accuracy'][-1] * 100
final_val_acc = history.history['val_accuracy'][-1] * 100
print("\n? **Final Accuracy Results:**")
print(f"? Training Accuracy: {final_train_acc:.2f}%")
print(f"? Validation Accuracy: {final_val_acc:.2f}%")

# ? Save training history
df_history = pd.DataFrame(history.history)
df_history.to_csv(os.path.join(logs_folder, 'epoch_wise_results.csv'), index=False)
print(f"? Training history saved at: {logs_folder}/epoch_wise_results.csv")

# ? Save final model
final_model_path = os.path.join(epoch_results_folder, 'final_alexnet_model.h5')
model.save(final_model_path)
print(f"? Final model saved at: {final_model_path}")
