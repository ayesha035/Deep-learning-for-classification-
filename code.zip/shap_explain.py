
import json
import shap
import tensorflow as tf
import numpy as np
import cv2
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing import image

# Load trained ResNet50 model
model_path = "/home5/ayesha.cse/mycode/data/bestresultsRELU/epoch_results/final_resnet50_model.h5"
model = tf.keras.models.load_model(model_path)

# Define class names
class_names = ["adenocarcinoma", "benign", "squamous_cell_carcinoma"]

# Function to load and preprocess images
def load_and_preprocess_image(img_path, target_size=(512, 512)):
    img = image.load_img(img_path, target_size=target_size)  # Resize to 512x512
    img_array = image.img_to_array(img)  # Convert to NumPy array
    img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
    img_array = img_array / 255.0  # Normalize
    return img_array

# Load test images
test_images = ["/home5/ayesha.cse/mycode/data/benign/0088.jpg"]  # Update paths
X = np.vstack([load_and_preprocess_image(img) for img in test_images])  # Stack images

# Function for SHAP explainer
def f(X):
    return model.predict(X)

# Fixed Blur Issue: Less blur for better visibility
masker = shap.maskers.Image("blur(5,5)", X[0].shape)  # Reduced blur

# Define SHAP explainer
explainer = shap.Explainer(f, masker, output_names=class_names)

# Compute SHAP values
shap_values = explainer(X, max_evals=1000, batch_size=16, outputs=shap.Explanation.argsort.flip[:1])

# Get model's prediction probabilities
predictions = model.predict(X)

# --- Create New Figure with Space for Probabilities ---
fig, ax = plt.subplots(figsize=(8, 5))  # Widen figure to accommodate text

# SHAP Explanation Plot
shap.image_plot(shap_values, show=False)

# --- Add Probability Text Outside the Image (Right Side) ---
#prob_text = "\n".join([f"{class_name}: {prob:.2%}" for class_name, prob in zip(class_names, predictions[0])])
#plt.figtext(0.85, 0.5, prob_text, fontsize=8, color="black", ha="left", va="center", bbox=dict(facecolor='white', alpha=0.6))
# --- Add a Slim Probability Bar on the Right Side ---
prob_text = "\n".join([f"{class_name}: {prob:.2%}" for class_name, prob in zip(class_names, predictions[0])])

plt.figtext(0.92, 0.5, prob_text, fontsize=10, color="black", ha="left", va="center", 
            bbox=dict(facecolor='white', edgecolor='black', boxstyle="round,pad=0.2", alpha=0.8))

# Save SHAP explanation with probabilities
plt.savefig("shap_results_with_probs.png", dpi=300, bbox_inches="tight")
plt.close()
