# Define location of the dataset
folder = '/mycode/data'

from numpy import load
import os
import numpy as np
from shutil import copy2

# Define split ratio and directories
train_ratio = 0.8  # 80% for training
base_folder = '/home5/ayesha.cse/mycode/data'
output_train_folder = "/home5/ayesha.cse/mycode/data/train_data"

output_test_folder = "/home5/ayesha.cse/mycode/data/test_data"
subfolders = ['adenocarcinoma', 'benign', 'squamous_cell_carcinoma']

# Ensure output folders exist
for subfolder in subfolders:
    os.makedirs(os.path.join(output_train_folder, subfolder), exist_ok=True)
    os.makedirs(os.path.join(output_test_folder, subfolder), exist_ok=True)

# Process data and split into train/test folders
for subfolder in subfolders:
    folder_path = os.path.join(base_folder, subfolder)
    files = [file for file in os.listdir(folder_path) if file.endswith(('.png', '.jpg', '.jpeg'))]

    # Shuffle files for randomness
    np.random.shuffle(files)

    # Split into train and test sets
    split_index = int(len(files) * train_ratio)
    train_files = files[:split_index]
    test_files = files[split_index:]

    # Copy training files
    for file in train_files:
        source_path = os.path.join(folder_path, file)
        destination_path = os.path.join(output_train_folder, subfolder, file)
        copy2(source_path, destination_path)

    # Copy testing files
    for file in test_files:
        source_path = os.path.join(folder_path, file)
        destination_path = os.path.join(output_test_folder, subfolder, file)
        copy2(source_path, destination_path)

    print(f"Processed {subfolder}: Train = {len(train_files)}, Test = {len(test_files)}")

print("Data successfully split into training and testing folders.")





