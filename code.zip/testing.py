from keras.models import load_model
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, roc_auc_score

#  Load the trained model
model_path = "/home5/ayesha.cse/mycode/data/bestresultsRELU/epoch_results/final_resnet50_model.h5"
model = load_model(model_path)
print("? Model Loaded Successfully!")

#  Load test dataset
test_folder = "/home5/ayesha.cse/mycode/data/test_data"
test_datagen = ImageDataGenerator(rescale=1.0/255.0)

test_generator = test_datagen.flow_from_directory(
    test_folder,
    target_size=(512, 512),
    batch_size=16,
    class_mode='categorical',
    shuffle=False  # Keep order of labels & predictions the same
)

print(f"? Total Test Samples: {test_generator.samples}")
print("Class Indices:", test_generator.class_indices)  # ? Ensures correct label mapping

#  Evaluate model on test dataset
test_loss, test_accuracy = model.evaluate(test_generator, verbose=1)

#  Get true labels
y_true = test_generator.classes  # Ground truth class labels
num_classes = len(test_generator.class_indices)
y_true_onehot = np.eye(num_classes)[y_true]  # Convert to one-hot encoding

#  Predict all test images
predictions = model.predict(test_generator, verbose=1)
y_pred = np.argmax(predictions, axis=1)  # Convert one-hot predictions to class indices

#  Compute Overall Metrics
precision = precision_score(y_true, y_pred, average='macro', zero_division=1)  
recall = recall_score(y_true, y_pred, average='macro', zero_division=1)
f1 = f1_score(y_true, y_pred, average='macro', zero_division=1)


print(f"? Overall Precision: {precision:.4f}")
print(f"? Overall Recall: {recall:.4f}")
print(f"? Overall F1-Score: {f1:.4f}")

#  Save overall metrics to CSV
df_metrics = pd.DataFrame({
    "Metric": ["Accuracy", "Precision", "Recall", "F1-Score"],
    "Score": [test_accuracy, precision, recall, f1]
})
df_metrics.to_csv("/home5/ayesha.cse/mycode/data/overall_metrics.csv", index=False)
print("? Overall Metrics Saved!")

