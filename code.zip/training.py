import os
import pandas as pd
from keras.applications import ResNet50
from keras.models import Model
from keras.layers import Dense, Dropout, GlobalAveragePooling2D, BatchNormalization, ReLU
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import ModelCheckpoint, CSVLogger
from keras.optimizers import Adam
import tensorflow as tf

#  Define directories
train_folder = "/home5/ayesha.cse/mycode/data/train_data"
epoch_results_folder = "/home5/ayesha.cse/mycode/data/epoch_results/"
logs_folder = "/home5/ayesha.cse/mycode/data/logs/"

#  Ensure epoch results and logs folders exist
os.makedirs(epoch_results_folder, exist_ok=True)
os.makedirs(logs_folder, exist_ok=True)

#  Hyperparameters
batch_size = 16
epochs = 3  # Increased for better training
num_classes = 3  # Number of classes in your dataset
input_shape = (512, 512, 3)  # Using 512x512 image size

#  Create ImageDataGenerator with validation split
#datagen = ImageDataGenerator(rescale=1.0/255.0, validation_split=0.2)  # 20% validation split
datagen = ImageDataGenerator(rescale=1.0/255.0, validation_split=0.3)  # ?? Increased from 0.2 to 0.3


#  Training Data (80% of dataset)
train_generator = datagen.flow_from_directory(
    train_folder,
    target_size=(512, 512),
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=True,
    subset='training'
)

#  Validation Data (20% of dataset)
val_generator = datagen.flow_from_directory(
    train_folder,
    target_size=(512, 512),
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=False,
    subset='validation'
)

#  Print dataset sizes before training
print(f"? Total Training Samples: {train_generator.samples}")
print(f"? Total Validation Samples: {val_generator.samples}")

#  Load ResNet50 pre-trained model
base_model = ResNet50(weights='imagenet', include_top=False, input_shape=input_shape)

#  Define the model architecture
x = base_model.output
x = GlobalAveragePooling2D()(x)

#  First Dense Layer
x = Dense(256)(x)
x = BatchNormalization()(x)
x = ReLU()(x)
x = Dropout(0.6)(x)

#  Second Dense Layer
x = Dense(128)(x)
x = BatchNormalization()(x)
x = ReLU()(x)
x = Dropout(0.6)(x)

#  Output Layer
outputs = Dense(num_classes, activation='softmax')(x)

#  Create the full model
model = Model(inputs=base_model.input, outputs=outputs)

#  Fine-tune the last 50 layers of ResNet50
for layer in base_model.layers[-50:]:  
    layer.trainable = True

#  Compile the model
model.compile(optimizer=Adam(learning_rate=0.00001), 
              loss=tf.keras.losses.CategoricalCrossentropy(from_logits=False),  # ? Ensure stable loss
              #loss='categorical_crossentropy',  
              metrics=['accuracy'])  # Only 'accuracy', Keras tracks 'val_accuracy' automatically

#  Save model checkpoints after each epoch
checkpoint_callback = ModelCheckpoint(
    filepath=os.path.join(epoch_results_folder, 'epoch_{epoch:02d}.h5'),
    monitor='val_accuracy',  # Monitor validation accuracy
    save_best_only=True,
    verbose=1
)

#  Save training logs to CSV for each epoch
csv_logger = CSVLogger(os.path.join(logs_folder, 'training_log.csv'), append=True)

#  Train the model and print progress
history = model.fit(
    train_generator,
    validation_data=val_generator,  
    epochs=epochs,
    callbacks=[checkpoint_callback, csv_logger]
)

#  Print final training and validation accuracy
final_train_acc = history.history['accuracy'][-1] * 100
final_val_acc = history.history['val_accuracy'][-1] * 100
print("\n? **Final Accuracy Results:**")
print(f"? Training Accuracy: {final_train_acc:.2f}%")
print(f"? Validation Accuracy: {final_val_acc:.2f}%")

#  Save training history
df_history = pd.DataFrame(history.history)
df_history.to_csv(os.path.join(logs_folder, 'epoch_wise_results.csv'), index=False)
print(f"? Training history saved at: {logs_folder}/epoch_wise_results.csv")

# Save final model
final_model_path = os.path.join(epoch_results_folder, 'final_resnet50_model.h5')
model.save(final_model_path)
print(f"? Final model saved at: {final_model_path}")
